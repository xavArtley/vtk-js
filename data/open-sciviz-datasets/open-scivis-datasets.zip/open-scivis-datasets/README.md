The datasets can be found at [klacansky.com/open-scivis-datasets/](https://klacansky.com/open-scivis-datasets/).

All data is little-endian.

If you would like to contribute dataset, please open issue and provide modified `template.json` file with a link to raw volume.

Please, cite the repository to improve reproducibility.

```
@misc{scivisdata,
   title = {Open SciVis Datasets},
   author = {Pavol Klacansky},
   year = {2017},
   month = {October},
   note = {\small \texttt{https://klacansky.com/open-scivis-datasets/}},
   url = {https://klacansky.com/open-scivis-datasets/}
}
```
